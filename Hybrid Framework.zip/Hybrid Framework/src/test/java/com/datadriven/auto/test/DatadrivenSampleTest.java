package com.datadriven.auto.test;

/* =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 * Author: Nagaraju.Meka
 * File: SampleTest.java
 * Created: 11/25/16
 * Description: Class to help normalize startup and usage of
 * retrieving the objects from Jenkins/Properties file.
 * -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=- */
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.datadriven.auto.base.AutomationBaseTest;
import com.datadriven.auto.expect.Expect;
import com.datadriven.auto.pageobjects.AutomationSampleScreen;

public class DatadrivenSampleTest extends AutomationBaseTest
{
   protected static final Logger log = LoggerFactory.getLogger(DatadrivenSampleTest.class);
   private final AutomationSampleScreen ss = new AutomationSampleScreen();


   @BeforeMethod
   public void setBeforeTest(Method method)
   {
      aController.launchBrowser(method);
      ss.setWebFunctions(aController.getwebController());
      setWebFunctions(aController.getwebController());
   }


   @AfterTest
   public void closeBrowser()
   {
      log.info("Closing the browser");
      aController.quitBrowser();
   }


   @Test(description = "Sample test case", groups = "sample-test", priority = 1)
   public void testSampleTest()
   {
      log.info("Alert present: {}", ss.checkAlert());
      assertTrue( !ss.checkAlert(), "");
      assertElementExist(AutomationSampleScreen.SEARCHMENU);
      Expect.expect("{Actual Message} contains {Expected Message}", "www.google.com", "www.google.com");
   }
}
